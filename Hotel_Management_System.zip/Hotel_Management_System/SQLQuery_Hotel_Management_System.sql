CREATE DATABASE Hotel_Management_System;

CREATE TABLE User_Table
(
	User_ID INT IDENTITY(1, 1) NOT NULL,
	User_Name VARCHAR(150) UNIQUE NOT NULL,
	User_Password VARCHAR(150) NOT NULL,
	CONSTRAINT User_Table_User_ID_PK PRIMARY KEY (User_ID)
);

INSERT INTO User_Table VALUES
	('Testing', '1234'),
	('User', '1234'),
	('NTU', '1176');

DROP TABLE User_Table;

CREATE TABLE User_Table
(
	User_ID INT IDENTITY(1, 1) NOT NULL,
	User_Name VARCHAR(150) UNIQUE NOT NULL,
	User_Password VARCHAR(150) NOT NULL,
	CONSTRAINT User_Table_User_ID_PK PRIMARY KEY (User_ID)
);

INSERT INTO User_Table (User_Name, User_Password) VALUES
	('User', '1234'),
	('NTU', '1176');

SELECT * FROM User_Table;