﻿namespace Hotel_Management_System
{
    partial class FormDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormDashboard));
            panel1 = new Panel();
            buttonDashbrd = new Button();
            buttonSettings = new Button();
            buttonReservations = new Button();
            buttonRooms = new Button();
            buttonClient = new Button();
            panel3 = new Panel();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            panel2 = new Panel();
            label1 = new Label();
            panel4 = new Panel();
            labelUsername = new Label();
            label6 = new Label();
            panel5 = new Panel();
            labelDateTime = new Label();
            pictureBox1 = new PictureBox();
            linkLabelLogOut = new LinkLabel();
            panel6 = new Panel();
            userControlSetting1 = new User_Control.UserControlSetting();
            timer1 = new System.Windows.Forms.Timer(components);
            panel1.SuspendLayout();
            panel3.SuspendLayout();
            panel2.SuspendLayout();
            panel4.SuspendLayout();
            panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel6.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(9, 121, 105);
            panel1.Controls.Add(buttonDashbrd);
            panel1.Controls.Add(buttonSettings);
            panel1.Controls.Add(buttonReservations);
            panel1.Controls.Add(buttonRooms);
            panel1.Controls.Add(buttonClient);
            panel1.Controls.Add(panel3);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(264, 720);
            panel1.TabIndex = 0;
            // 
            // buttonDashbrd
            // 
            buttonDashbrd.BackColor = Color.FromArgb(175, 225, 175);
            buttonDashbrd.FlatAppearance.BorderSize = 0;
            buttonDashbrd.FlatStyle = FlatStyle.Flat;
            buttonDashbrd.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonDashbrd.ForeColor = Color.White;
            buttonDashbrd.Location = new Point(25, 213);
            buttonDashbrd.Name = "buttonDashbrd";
            buttonDashbrd.Size = new Size(215, 46);
            buttonDashbrd.TabIndex = 6;
            buttonDashbrd.Text = "Dashboard";
            buttonDashbrd.UseVisualStyleBackColor = false;
            // 
            // buttonSettings
            // 
            buttonSettings.BackColor = Color.FromArgb(175, 225, 175);
            buttonSettings.FlatAppearance.BorderSize = 0;
            buttonSettings.FlatStyle = FlatStyle.Flat;
            buttonSettings.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonSettings.ForeColor = Color.White;
            buttonSettings.Location = new Point(25, 488);
            buttonSettings.Name = "buttonSettings";
            buttonSettings.Size = new Size(215, 46);
            buttonSettings.TabIndex = 5;
            buttonSettings.Text = "Settings";
            buttonSettings.UseVisualStyleBackColor = false;
            buttonSettings.Click += buttonSettings_Click;
            // 
            // buttonReservations
            // 
            buttonReservations.BackColor = Color.FromArgb(175, 225, 175);
            buttonReservations.FlatAppearance.BorderSize = 0;
            buttonReservations.FlatStyle = FlatStyle.Flat;
            buttonReservations.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonReservations.ForeColor = Color.White;
            buttonReservations.Location = new Point(25, 421);
            buttonReservations.Name = "buttonReservations";
            buttonReservations.Size = new Size(215, 46);
            buttonReservations.TabIndex = 4;
            buttonReservations.Text = "Reservations";
            buttonReservations.UseVisualStyleBackColor = false;
            // 
            // buttonRooms
            // 
            buttonRooms.BackColor = Color.FromArgb(175, 225, 175);
            buttonRooms.FlatAppearance.BorderSize = 0;
            buttonRooms.FlatStyle = FlatStyle.Flat;
            buttonRooms.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonRooms.ForeColor = Color.White;
            buttonRooms.Location = new Point(25, 351);
            buttonRooms.Name = "buttonRooms";
            buttonRooms.Size = new Size(215, 46);
            buttonRooms.TabIndex = 3;
            buttonRooms.Text = "Rooms";
            buttonRooms.UseVisualStyleBackColor = false;
            // 
            // buttonClient
            // 
            buttonClient.BackColor = Color.FromArgb(175, 225, 175);
            buttonClient.FlatAppearance.BorderSize = 0;
            buttonClient.FlatStyle = FlatStyle.Flat;
            buttonClient.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonClient.ForeColor = Color.White;
            buttonClient.Location = new Point(25, 280);
            buttonClient.Name = "buttonClient";
            buttonClient.Size = new Size(215, 46);
            buttonClient.TabIndex = 2;
            buttonClient.Text = "Client";
            buttonClient.UseVisualStyleBackColor = false;
            // 
            // panel3
            // 
            panel3.Controls.Add(label4);
            panel3.Controls.Add(label3);
            panel3.Controls.Add(label2);
            panel3.Dock = DockStyle.Top;
            panel3.Location = new Point(0, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(264, 189);
            panel3.TabIndex = 0;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Century Gothic", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.White;
            label4.Location = new Point(78, 133);
            label4.Name = "label4";
            label4.Size = new Size(119, 37);
            label4.TabIndex = 0;
            label4.Text = "System";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Century Gothic", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(21, 83);
            label3.Name = "label3";
            label3.Size = new Size(215, 37);
            label3.TabIndex = 0;
            label3.Text = "Management";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century Gothic", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(78, 34);
            label2.Name = "label2";
            label2.Size = new Size(91, 37);
            label2.TabIndex = 0;
            label2.Text = "Hotel";
            // 
            // panel2
            // 
            panel2.Controls.Add(label1);
            panel2.Dock = DockStyle.Bottom;
            panel2.Location = new Point(264, 662);
            panel2.Name = "panel2";
            panel2.Size = new Size(1102, 58);
            panel2.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(8, 20);
            label1.Name = "label1";
            label1.Size = new Size(325, 21);
            label1.TabIndex = 0;
            label1.Text = "Copyright © 2024. All Rights Reserved. \r\n";
            label1.Click += label1_Click;
            // 
            // panel4
            // 
            panel4.BackColor = Color.FromArgb(9, 121, 105);
            panel4.Controls.Add(labelUsername);
            panel4.Controls.Add(label6);
            panel4.Controls.Add(panel5);
            panel4.Dock = DockStyle.Top;
            panel4.Location = new Point(264, 0);
            panel4.Name = "panel4";
            panel4.Size = new Size(1102, 154);
            panel4.TabIndex = 0;
            // 
            // labelUsername
            // 
            labelUsername.BackColor = Color.FromArgb(9, 121, 105);
            labelUsername.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelUsername.ForeColor = Color.White;
            labelUsername.Location = new Point(132, 97);
            labelUsername.Name = "labelUsername";
            labelUsername.Size = new Size(244, 23);
            labelUsername.TabIndex = 3;
            labelUsername.Text = "?";
            // 
            // label6
            // 
            label6.BackColor = Color.FromArgb(9, 121, 105);
            label6.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.White;
            label6.Location = new Point(8, 97);
            label6.Name = "label6";
            label6.Size = new Size(118, 23);
            label6.TabIndex = 2;
            label6.Text = "Welcome :";
            // 
            // panel5
            // 
            panel5.BackColor = Color.White;
            panel5.Controls.Add(labelDateTime);
            panel5.Controls.Add(pictureBox1);
            panel5.Controls.Add(linkLabelLogOut);
            panel5.Dock = DockStyle.Top;
            panel5.Location = new Point(0, 0);
            panel5.Name = "panel5";
            panel5.Size = new Size(1102, 79);
            panel5.TabIndex = 1;
            panel5.Paint += panel5_Paint;
            // 
            // labelDateTime
            // 
            labelDateTime.Font = new Font("Century Gothic", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelDateTime.Location = new Point(22, 48);
            labelDateTime.Name = "labelDateTime";
            labelDateTime.Size = new Size(455, 23);
            labelDateTime.TabIndex = 0;
            // 
            // pictureBox1
            // 
            pictureBox1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            pictureBox1.Image = Properties.Resources.png_transparent_user_profile_computer_icons_login_user_avatars_thumbnail;
            pictureBox1.Location = new Point(871, 22);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(42, 54);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // linkLabelLogOut
            // 
            linkLabelLogOut.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            linkLabelLogOut.AutoSize = true;
            linkLabelLogOut.Cursor = Cursors.Hand;
            linkLabelLogOut.DisabledLinkColor = Color.FromArgb(53, 94, 59);
            linkLabelLogOut.Font = new Font("Century Gothic", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            linkLabelLogOut.ForeColor = Color.FromArgb(53, 94, 59);
            linkLabelLogOut.LinkColor = Color.FromArgb(53, 94, 59);
            linkLabelLogOut.Location = new Point(919, 49);
            linkLabelLogOut.Name = "linkLabelLogOut";
            linkLabelLogOut.Size = new Size(78, 22);
            linkLabelLogOut.TabIndex = 0;
            linkLabelLogOut.TabStop = true;
            linkLabelLogOut.Text = "Log Out";
            linkLabelLogOut.VisitedLinkColor = Color.FromArgb(53, 94, 59);
            linkLabelLogOut.LinkClicked += linkLabelLogOut_LinkClicked;
            // 
            // panel6
            // 
            panel6.Controls.Add(userControlSetting1);
            panel6.Dock = DockStyle.Fill;
            panel6.Location = new Point(264, 154);
            panel6.Name = "panel6";
            panel6.Size = new Size(1102, 508);
            panel6.TabIndex = 0;
            panel6.Paint += panel6_Paint;
            // 
            // userControlSetting1
            // 
            userControlSetting1.BackColor = Color.White;
            userControlSetting1.Dock = DockStyle.Fill;
            userControlSetting1.Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            userControlSetting1.Location = new Point(0, 0);
            userControlSetting1.Name = "userControlSetting1";
            userControlSetting1.Size = new Size(1102, 508);
            userControlSetting1.TabIndex = 0;
            userControlSetting1.Visible = false;
            userControlSetting1.Load += userControlSetting1_Load;
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // FormDashboard
            // 
            AutoScaleDimensions = new SizeF(10F, 21F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1366, 720);
            Controls.Add(panel6);
            Controls.Add(panel4);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "FormDashboard";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Hotel_Management_System | Dashboard";
            WindowState = FormWindowState.Maximized;
            Load += FormDashboard_Load;
            panel1.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel4.ResumeLayout(false);
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel6.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Panel panel3;
        private Panel panel4;
        private Panel panel5;
        private Label label1;
        private LinkLabel linkLabelLogOut;
        private PictureBox pictureBox1;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label labelDateTime;
        private Label labelUsername;
        private Label label6;
        private Button buttonDashboard;
        private Button buttonSettings;
        private Button buttonReservations;
        private Button buttonRooms;
        private Button buttonClient;
        private Panel panel6;
        private System.Windows.Forms.Timer timer1;
        private Button buttonDashbrd;
        private User_Control.UserControlSetting userControlSetting1;
    }
}