﻿namespace Hotel_Management_System.User_Control
{
    partial class UserControlSetting
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabControlUser = new TabControl();
            tabPageAddUser = new TabPage();
            buttonAdd = new Button();
            textBoxPassword = new TextBox();
            label3 = new Label();
            textBoxUsername = new TextBox();
            label2 = new Label();
            label1 = new Label();
            tabPageSearchUser = new TabPage();
            dataGridViewUser = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            textBoxSearchUsername = new TextBox();
            label5 = new Label();
            label4 = new Label();
            tabPageUpdateandDeleteUser = new TabPage();
            buttonDelete = new Button();
            buttonUpdate = new Button();
            textBoxPassword1 = new TextBox();
            label6 = new Label();
            textBoxUsername1 = new TextBox();
            label7 = new Label();
            label8 = new Label();
            tabControlUser.SuspendLayout();
            tabPageAddUser.SuspendLayout();
            tabPageSearchUser.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewUser).BeginInit();
            tabPageUpdateandDeleteUser.SuspendLayout();
            SuspendLayout();
            // 
            // tabControlUser
            // 
            tabControlUser.Alignment = TabAlignment.Bottom;
            tabControlUser.Anchor = AnchorStyles.None;
            tabControlUser.Controls.Add(tabPageAddUser);
            tabControlUser.Controls.Add(tabPageSearchUser);
            tabControlUser.Controls.Add(tabPageUpdateandDeleteUser);
            tabControlUser.Location = new Point(22, 3);
            tabControlUser.Name = "tabControlUser";
            tabControlUser.SelectedIndex = 0;
            tabControlUser.Size = new Size(1031, 402);
            tabControlUser.TabIndex = 0;
            // 
            // tabPageAddUser
            // 
            tabPageAddUser.BackColor = Color.White;
            tabPageAddUser.Controls.Add(buttonAdd);
            tabPageAddUser.Controls.Add(textBoxPassword);
            tabPageAddUser.Controls.Add(label3);
            tabPageAddUser.Controls.Add(textBoxUsername);
            tabPageAddUser.Controls.Add(label2);
            tabPageAddUser.Controls.Add(label1);
            tabPageAddUser.Location = new Point(4, 4);
            tabPageAddUser.Name = "tabPageAddUser";
            tabPageAddUser.Padding = new Padding(3);
            tabPageAddUser.Size = new Size(1023, 368);
            tabPageAddUser.TabIndex = 0;
            tabPageAddUser.Text = "Add User";
            tabPageAddUser.Leave += tabPageAddUser_Leave;
            // 
            // buttonAdd
            // 
            buttonAdd.Anchor = AnchorStyles.None;
            buttonAdd.BackColor = Color.FromArgb(0, 86, 59);
            buttonAdd.Cursor = Cursors.Hand;
            buttonAdd.FlatAppearance.BorderSize = 0;
            buttonAdd.FlatStyle = FlatStyle.Flat;
            buttonAdd.Font = new Font("Century Gothic", 10.8F, FontStyle.Bold);
            buttonAdd.ForeColor = Color.White;
            buttonAdd.Location = new Point(203, 169);
            buttonAdd.Name = "buttonAdd";
            buttonAdd.Size = new Size(122, 35);
            buttonAdd.TabIndex = 5;
            buttonAdd.Text = "Add";
            buttonAdd.UseVisualStyleBackColor = false;
            buttonAdd.Click += buttonAdd_Click;
            // 
            // textBoxPassword
            // 
            textBoxPassword.Anchor = AnchorStyles.None;
            textBoxPassword.Location = new Point(544, 120);
            textBoxPassword.Name = "textBoxPassword";
            textBoxPassword.Size = new Size(296, 28);
            textBoxPassword.TabIndex = 4;
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.Font = new Font("Century Gothic", 10.8F, FontStyle.Bold);
            label3.Location = new Point(538, 96);
            label3.Name = "label3";
            label3.Size = new Size(97, 22);
            label3.TabIndex = 3;
            label3.Text = "Password:";
            // 
            // textBoxUsername
            // 
            textBoxUsername.Anchor = AnchorStyles.None;
            textBoxUsername.Location = new Point(198, 120);
            textBoxUsername.Name = "textBoxUsername";
            textBoxUsername.Size = new Size(296, 28);
            textBoxUsername.TabIndex = 2;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.Font = new Font("Century Gothic", 10.8F, FontStyle.Bold);
            label2.Location = new Point(192, 96);
            label2.Name = "label2";
            label2.Size = new Size(105, 22);
            label2.TabIndex = 1;
            label2.Text = "Username:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(0, 86, 59);
            label1.Location = new Point(3, 3);
            label1.Name = "label1";
            label1.Size = new Size(95, 22);
            label1.TabIndex = 0;
            label1.Text = "Add User:";
            // 
            // tabPageSearchUser
            // 
            tabPageSearchUser.Controls.Add(dataGridViewUser);
            tabPageSearchUser.Controls.Add(textBoxSearchUsername);
            tabPageSearchUser.Controls.Add(label5);
            tabPageSearchUser.Controls.Add(label4);
            tabPageSearchUser.Location = new Point(4, 4);
            tabPageSearchUser.Name = "tabPageSearchUser";
            tabPageSearchUser.Padding = new Padding(3);
            tabPageSearchUser.Size = new Size(1023, 368);
            tabPageSearchUser.TabIndex = 1;
            tabPageSearchUser.Text = "Search User";
            tabPageSearchUser.UseVisualStyleBackColor = true;
            tabPageSearchUser.Enter += tabPageSearchUser_Enter;
            tabPageSearchUser.Leave += tabPageSearchUser_Leave;
            // 
            // dataGridViewUser
            // 
            dataGridViewUser.AllowUserToAddRows = false;
            dataGridViewUser.AllowUserToDeleteRows = false;
            dataGridViewUser.Anchor = AnchorStyles.None;
            dataGridViewUser.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewUser.BorderStyle = BorderStyle.None;
            dataGridViewUser.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewUser.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3 });
            dataGridViewUser.Location = new Point(26, 110);
            dataGridViewUser.Name = "dataGridViewUser";
            dataGridViewUser.ReadOnly = true;
            dataGridViewUser.RowHeadersWidth = 51;
            dataGridViewUser.Size = new Size(974, 234);
            dataGridViewUser.TabIndex = 5;
            dataGridViewUser.CellClick += dataGridViewUser_CellClick;
            // 
            // Column1
            // 
            Column1.DataPropertyName = "User_ID";
            Column1.HeaderText = "ID";
            Column1.MinimumWidth = 6;
            Column1.Name = "Column1";
            Column1.ReadOnly = true;
            // 
            // Column2
            // 
            Column2.DataPropertyName = "User_Name";
            Column2.HeaderText = "Username";
            Column2.MinimumWidth = 6;
            Column2.Name = "Column2";
            Column2.ReadOnly = true;
            // 
            // Column3
            // 
            Column3.DataPropertyName = "User_Password";
            Column3.HeaderText = "Password";
            Column3.MinimumWidth = 6;
            Column3.Name = "Column3";
            Column3.ReadOnly = true;
            // 
            // textBoxSearchUsername
            // 
            textBoxSearchUsername.Anchor = AnchorStyles.None;
            textBoxSearchUsername.Location = new Point(197, 61);
            textBoxSearchUsername.Name = "textBoxSearchUsername";
            textBoxSearchUsername.Size = new Size(296, 28);
            textBoxSearchUsername.TabIndex = 4;
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.Font = new Font("Century Gothic", 10.8F, FontStyle.Bold);
            label5.Location = new Point(191, 37);
            label5.Name = "label5";
            label5.Size = new Size(105, 22);
            label5.TabIndex = 3;
            label5.Text = "Username:";
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Century Gothic", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.FromArgb(0, 86, 59);
            label4.Location = new Point(3, 3);
            label4.Name = "label4";
            label4.Size = new Size(120, 22);
            label4.TabIndex = 0;
            label4.Text = "Search User:";
            label4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // tabPageUpdateandDeleteUser
            // 
            tabPageUpdateandDeleteUser.Controls.Add(buttonDelete);
            tabPageUpdateandDeleteUser.Controls.Add(buttonUpdate);
            tabPageUpdateandDeleteUser.Controls.Add(textBoxPassword1);
            tabPageUpdateandDeleteUser.Controls.Add(label6);
            tabPageUpdateandDeleteUser.Controls.Add(textBoxUsername1);
            tabPageUpdateandDeleteUser.Controls.Add(label7);
            tabPageUpdateandDeleteUser.Controls.Add(label8);
            tabPageUpdateandDeleteUser.Location = new Point(4, 4);
            tabPageUpdateandDeleteUser.Name = "tabPageUpdateandDeleteUser";
            tabPageUpdateandDeleteUser.Padding = new Padding(3);
            tabPageUpdateandDeleteUser.Size = new Size(1023, 368);
            tabPageUpdateandDeleteUser.TabIndex = 2;
            tabPageUpdateandDeleteUser.Text = "Update and Delete User";
            tabPageUpdateandDeleteUser.UseVisualStyleBackColor = true;
            tabPageUpdateandDeleteUser.Leave += tabPageUpdateandDeleteUser_Leave;
            // 
            // buttonDelete
            // 
            buttonDelete.Anchor = AnchorStyles.None;
            buttonDelete.BackColor = Color.FromArgb(255, 128, 0);
            buttonDelete.Cursor = Cursors.Hand;
            buttonDelete.FlatAppearance.BorderSize = 0;
            buttonDelete.FlatStyle = FlatStyle.Flat;
            buttonDelete.Font = new Font("Century Gothic", 10.8F, FontStyle.Bold);
            buttonDelete.ForeColor = Color.White;
            buttonDelete.Location = new Point(347, 169);
            buttonDelete.Name = "buttonDelete";
            buttonDelete.Size = new Size(122, 35);
            buttonDelete.TabIndex = 12;
            buttonDelete.Text = "Delete";
            buttonDelete.UseVisualStyleBackColor = false;
            buttonDelete.Click += buttonDelete_Click;
            // 
            // buttonUpdate
            // 
            buttonUpdate.Anchor = AnchorStyles.None;
            buttonUpdate.BackColor = Color.FromArgb(0, 86, 59);
            buttonUpdate.Cursor = Cursors.Hand;
            buttonUpdate.FlatAppearance.BorderSize = 0;
            buttonUpdate.FlatStyle = FlatStyle.Flat;
            buttonUpdate.Font = new Font("Century Gothic", 10.8F, FontStyle.Bold);
            buttonUpdate.ForeColor = Color.White;
            buttonUpdate.Location = new Point(201, 169);
            buttonUpdate.Name = "buttonUpdate";
            buttonUpdate.Size = new Size(122, 35);
            buttonUpdate.TabIndex = 11;
            buttonUpdate.Text = "Update";
            buttonUpdate.UseVisualStyleBackColor = false;
            buttonUpdate.Click += buttonUpdate_Click;
            // 
            // textBoxPassword1
            // 
            textBoxPassword1.Anchor = AnchorStyles.None;
            textBoxPassword1.Location = new Point(544, 120);
            textBoxPassword1.Name = "textBoxPassword1";
            textBoxPassword1.Size = new Size(296, 28);
            textBoxPassword1.TabIndex = 10;
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.None;
            label6.AutoSize = true;
            label6.Font = new Font("Century Gothic", 10.8F, FontStyle.Bold);
            label6.Location = new Point(538, 96);
            label6.Name = "label6";
            label6.Size = new Size(97, 22);
            label6.TabIndex = 9;
            label6.Text = "Password:";
            // 
            // textBoxUsername1
            // 
            textBoxUsername1.Anchor = AnchorStyles.None;
            textBoxUsername1.Location = new Point(198, 120);
            textBoxUsername1.Name = "textBoxUsername1";
            textBoxUsername1.Size = new Size(296, 28);
            textBoxUsername1.TabIndex = 8;
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.None;
            label7.AutoSize = true;
            label7.Font = new Font("Century Gothic", 10.8F, FontStyle.Bold);
            label7.Location = new Point(192, 96);
            label7.Name = "label7";
            label7.Size = new Size(105, 22);
            label7.TabIndex = 7;
            label7.Text = "Username:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Century Gothic", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.FromArgb(0, 86, 59);
            label8.Location = new Point(3, 3);
            label8.Name = "label8";
            label8.Size = new Size(226, 22);
            label8.TabIndex = 6;
            label8.Text = "Update and Delete User:";
            // 
            // UserControlSetting
            // 
            AutoScaleDimensions = new SizeF(10F, 21F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            Controls.Add(tabControlUser);
            Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Name = "UserControlSetting";
            Size = new Size(1363, 594);
            tabControlUser.ResumeLayout(false);
            tabPageAddUser.ResumeLayout(false);
            tabPageAddUser.PerformLayout();
            tabPageSearchUser.ResumeLayout(false);
            tabPageSearchUser.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewUser).EndInit();
            tabPageUpdateandDeleteUser.ResumeLayout(false);
            tabPageUpdateandDeleteUser.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControlUser;
        private TabPage tabPageAddUser;
        private TabPage tabPageSearchUser;
        private Label label2;
        private Label label1;
        private TextBox textBoxPassword;
        private Label label3;
        private TextBox textBoxUsername;
        private Button buttonAdd;
        private DataGridView dataGridViewUser;
        private TextBox textBoxSearchUsername;
        private Label label5;
        private Label label4;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private TabPage tabPageUpdateandDeleteUser;
        private Button buttonUpdate;
        private TextBox textBoxPassword1;
        private Label label6;
        private TextBox textBoxUsername1;
        private Label label7;
        private Label label8;
        private Button buttonDelete;
    }
}
