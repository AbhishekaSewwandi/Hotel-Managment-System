﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;
using System.Windows.Forms;

namespace Hotel_Management_System.User_Control
{
    public partial class UserControlSetting : UserControl
    {
        string connectionString = "Server=LAPTOP-IU0L6L85; Database=Hotel_Management_System; Integrated Security=True;";
        private string ID = "";

        public UserControlSetting()
        {
            InitializeComponent();
        }

        public void Clear()
        {
            textBoxUsername.Clear();
            textBoxPassword.Clear();
            tabControlUser.SelectedTab = tabPageAddUser;
        }

        private void Clear1()
        {
            textBoxUsername1.Clear();
            textBoxPassword1.Clear();
            ID = "";
        }

        private void tabPageAddUser_Leave(object sender, EventArgs e)
        {
            Clear();
        }

        private void DisplayAndSearchUser(string query, DataGridView dgv)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open(); 
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(query, connection);

                    DataTable dataTable = new DataTable();
                    sqlDataAdapter.Fill(dataTable); 
                    dgv.DataSource = dataTable;
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("An error occurred while fetching the user data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void tabPageSearchUser_Enter(object sender, EventArgs e)
        {
            DisplayAndSearchUser("SELECT * FROM User_Table", dataGridViewUser);
        }

        private void tabPageSearchUser_Leave(object sender, EventArgs e)
        {
            textBoxSearchUsername.Clear();
        }

        private void tabPageUpdateandDeleteUser_Leave(object sender, EventArgs e)
        {
            Clear1();
        }

        private void buttonAdd_Click(object sender, EventArgs e)

        {
            if (textBoxUsername.Text.Trim() == string.Empty || textBoxPassword.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Please fill out all fields.", "All fields are required.", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                bool check = AddUser(textBoxUsername.Text.Trim(), textBoxPassword.Text.Trim());
                if (check)
                {
                    Clear();
                    MessageBox.Show("User added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }
        private bool AddUser(string username, string password)
        {
            bool result = false;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "INSERT INTO User_Table (User_Name, User_Password) VALUES (@User_Name, @User_Password)";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@User_Name", username);
                        command.Parameters.AddWithValue("@User_Password", password);

                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            result = true; 
                        }
                    }
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            return result;
        }

        private bool UpdateUser(string id, string username, string password)
        {
            bool isSuccess = false;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string query = "UPDATE User_Table SET User_Name = @username, User_Password = @password WHERE User_ID = @id";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@username", username);
                        command.Parameters.AddWithValue("@password", password);
                        command.Parameters.AddWithValue("@id", id);

                        int rowsAffected = command.ExecuteNonQuery();
                        isSuccess = rowsAffected > 0;
                    }
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("An error occurred while updating the user: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            return isSuccess; 
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            if (ID != "")
            {
                if (textBoxUsername1.Text.Trim() == string.Empty || textBoxPassword1.Text.Trim() == string.Empty)
                {
                    MessageBox.Show("Please fill out all fields.", "All fields are required.", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    bool check = UpdateUser(ID, textBoxUsername1.Text.Trim(), textBoxPassword1.Text.Trim());

                    if (check) 
                    {
                        Clear1();
                        MessageBox.Show("User updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Update failed. Please try again.", "Update Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            else
            {
                MessageBox.Show("No user selected for update.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool DeleteUser(string id)
        {
            bool isSuccess = false; 

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open(); 

                    string query = "DELETE FROM User_Table WHERE User_ID = @id";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@id", id);

                        int rowsAffected = command.ExecuteNonQuery();
                        isSuccess = rowsAffected > 0;
                    }
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("An error occurred while deleting the user: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            return isSuccess; 
        }


        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (ID != "") 
            {
                DialogResult result = MessageBox.Show("Are you sure you want to delete this user?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes) 
                {
                    bool check = DeleteUser(ID); 

                    if (check) 
                    {
                        Clear1(); 
                        MessageBox.Show("User deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Deletion failed. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            else
            {
                MessageBox.Show("No user selected for deletion.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void dataGridViewUser_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if(e.RowIndex != -1)
            {
                DataGridViewRow row = dataGridViewUser.Rows[e.RowIndex];
                ID = row.Cells[0].Value.ToString();
                textBoxUsername1.Text = row.Cells[1].Value.ToString();
                textBoxPassword1.Text = row.Cells[2].Value.ToString();
            }
        }
    }
}
